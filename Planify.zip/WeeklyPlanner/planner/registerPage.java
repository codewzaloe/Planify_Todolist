
package planner;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

public class registerPage extends javax.swing.JFrame {


    public registerPage() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelSU = new javax.swing.JPanel();
        jLogoPanel = new javax.swing.JPanel();
        logoLaki = new javax.swing.JLabel();
        copyrightPlanify = new javax.swing.JLabel();
        planifyDesc = new javax.swing.JLabel();
        signUp = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        emailField = new javax.swing.JTextField();
        usernameField = new javax.swing.JTextField();
        passwordText = new javax.swing.JLabel();
        passwordField = new javax.swing.JTextField();
        registerButton = new javax.swing.JButton();
        askLogin = new java.awt.Label();
        loginButton = new javax.swing.JButton();
        signUpDesc = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(250, 237, 205));

        jPanelSU.setBackground(new java.awt.Color(250, 237, 205));
        jPanelSU.setPreferredSize(new java.awt.Dimension(800, 450));

        jLogoPanel.setBackground(new java.awt.Color(212, 163, 115));
        jLogoPanel.setPreferredSize(new java.awt.Dimension(400, 281));

        logoLaki.setIcon(new javax.swing.ImageIcon("C:\\Users\\Lenovo\\Downloads\\INI GAMBAR BARU.png")); // NOI18N

        copyrightPlanify.setFont(new java.awt.Font("Baskerville Old Face", 0, 12)); // NOI18N
        copyrightPlanify.setText("Copyright @Planify 2023 ");

        planifyDesc.setFont(new java.awt.Font("Baskerville Old Face", 3, 16)); // NOI18N
        planifyDesc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        planifyDesc.setText("your personal weekly planner");

        javax.swing.GroupLayout jLogoPanelLayout = new javax.swing.GroupLayout(jLogoPanel);
        jLogoPanel.setLayout(jLogoPanelLayout);
        jLogoPanelLayout.setHorizontalGroup(
            jLogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLogoPanelLayout.createSequentialGroup()
                .addGroup(jLogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLogoPanelLayout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(copyrightPlanify))
                    .addGroup(jLogoPanelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(logoLaki, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(55, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLogoPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(planifyDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(94, 94, 94))
        );
        jLogoPanelLayout.setVerticalGroup(
            jLogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLogoPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoLaki, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(planifyDesc)
                .addGap(123, 123, 123)
                .addComponent(copyrightPlanify)
                .addGap(23, 23, 23))
        );

        signUp.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        signUp.setText("Sign Up");

        email.setFont(new java.awt.Font("Baskerville Old Face", 0, 16)); // NOI18N
        email.setText("Email");

        username.setFont(new java.awt.Font("Baskerville Old Face", 0, 16)); // NOI18N
        username.setText("Username");

        emailField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        emailField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFieldActionPerformed(evt);
            }
        });

        usernameField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        passwordText.setFont(new java.awt.Font("Baskerville Old Face", 0, 16)); // NOI18N
        passwordText.setText("Password");

        passwordField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        registerButton.setBackground(new java.awt.Color(204, 213, 174));
        registerButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 14)); // NOI18N
        registerButton.setText("Register");
        registerButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        registerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerButtonActionPerformed(evt);
            }
        });

        askLogin.setFont(new java.awt.Font("Baskerville Old Face", 0, 14)); // NOI18N
        askLogin.setText("Don't have an account yet?");

        loginButton.setBackground(new java.awt.Color(212, 163, 115));
        loginButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 14)); // NOI18N
        loginButton.setText("Login");
        loginButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        signUpDesc.setFont(new java.awt.Font("Baskerville Old Face", 1, 16)); // NOI18N
        signUpDesc.setText("Start your own journey with Planify!");

        javax.swing.GroupLayout jPanelSULayout = new javax.swing.GroupLayout(jPanelSU);
        jPanelSU.setLayout(jPanelSULayout);
        jPanelSULayout.setHorizontalGroup(
            jPanelSULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSULayout.createSequentialGroup()
                .addComponent(jLogoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addGroup(jPanelSULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSULayout.createSequentialGroup()
                        .addGroup(jPanelSULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(email)
                            .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(username)
                            .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordText)
                            .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(registerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanelSULayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(signUpDesc)))
                        .addGap(46, 46, 46))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSULayout.createSequentialGroup()
                        .addComponent(signUp)
                        .addGap(122, 122, 122))
                    .addGroup(jPanelSULayout.createSequentialGroup()
                        .addComponent(askLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanelSULayout.setVerticalGroup(
            jPanelSULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLogoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
            .addGroup(jPanelSULayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(signUp)
                .addGap(18, 18, 18)
                .addComponent(signUpDesc)
                .addGap(25, 25, 25)
                .addComponent(username)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(email)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(registerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanelSULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(askLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelSU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelSU, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        loginPage loginFrame = new loginPage();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_loginButtonActionPerformed

    private void registerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerButtonActionPerformed
        //System.out.println("Sign Up btn clicked");
        String username, email, Password, query, query2;
        String SUrl, SUser, Spassword;
        SUrl = "jdbc:MySQL://localhost:3306/weeklyplanner";
        SUser = "root";
        Spassword = "";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, Spassword);
            Statement st = con.createStatement();
            if("".equals(usernameField.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Username is Required.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            }else if("".equals(emailField.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Email is Required", "Error",
                    JOptionPane.ERROR_MESSAGE);
            }else if("".equals(passwordField.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Password is Required", "Error",
                    JOptionPane.ERROR_MESSAGE);
            }else{
                username = usernameField.getText();
                email = emailField.getText();
                Password = passwordField.getText();
                System.out.println(Password);

                query = "INSERT INTO pengguna(username, email, passwordUser)"+
                "VALUES('"+username+"', '"+email+"', '"+Password+"')";

                st.execute(query);
                
                query2 = "INSERT INTO notes(username) VALUES ('"  + username + "')";
                
                st.execute(query2);
                
                usernameField.setText("");
                emailField.setText("");
                passwordField.setText("");
                showMessageDialog(null, "Account has been created successfully!");
            }
        }catch(HeadlessException | ClassNotFoundException | SQLException e){
            System.out.println("Error!"+ e.getMessage());

        }

    }//GEN-LAST:event_registerButtonActionPerformed

    private void emailFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailFieldActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Label askLogin;
    private javax.swing.JLabel copyrightPlanify;
    private javax.swing.JLabel email;
    private javax.swing.JTextField emailField;
    private javax.swing.JPanel jLogoPanel;
    private javax.swing.JPanel jPanelSU;
    private javax.swing.JButton loginButton;
    private javax.swing.JLabel logoLaki;
    private javax.swing.JTextField passwordField;
    private javax.swing.JLabel passwordText;
    private javax.swing.JLabel planifyDesc;
    private javax.swing.JButton registerButton;
    private javax.swing.JLabel signUp;
    private javax.swing.JLabel signUpDesc;
    private javax.swing.JLabel username;
    private javax.swing.JTextField usernameField;
    // End of variables declaration//GEN-END:variables
}
