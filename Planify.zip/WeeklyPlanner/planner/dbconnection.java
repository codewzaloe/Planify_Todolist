package planner;

import java.sql.*;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;

public class dbconnection {
    static Connection c;
    
    public static Connection getCon() throws Exception{
        if(c == null){
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost/weeklyplanner", "root", "");
        }
        return c;
    }
    
    public static void InsertData(String sql) throws Exception {
        getCon().createStatement().executeUpdate(sql);
    }
    
    public static String Printdata(String username) throws Exception{
        ResultSet rs = getCon().createStatement().executeQuery("SELECT * FROM notes WHERE username = '" + username + "'");
        String note = null;
        while(rs.next()){
            note = rs.getString("note");
        }
        return note;
    }
    
    public static DefaultListModel getList(String username, String table) throws Exception{
        DefaultListModel model = new DefaultListModel();
        ResultSet rs = getCon().createStatement().executeQuery("SELECT * FROM " + table + " WHERE username = '" + username + "'");
        while (rs.next()) {
            String data = rs.getString("todo");
            model.addElement(data); 
        }
        return model;
    }
    
    public static DefaultListModel getListDaily(String username, String table, String category) throws Exception{
        DefaultListModel model = new DefaultListModel();
        ResultSet rs = getCon().createStatement().executeQuery("SELECT * FROM " + table + " WHERE username = '" + username + "' AND category = '" + category +"'");
        while (rs.next()) {
            String data = rs.getString("todo");
            model.addElement(data); 
        }
        return model;
    }
}