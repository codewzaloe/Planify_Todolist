/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package planner;

/**
 *
 * @author Lenovo
 */
public class WeeklyProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        loginPage LoginFrame = new loginPage(); 
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
    }
    
}
