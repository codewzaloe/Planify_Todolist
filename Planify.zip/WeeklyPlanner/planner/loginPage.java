
package planner;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

public class loginPage extends javax.swing.JFrame {

    
    public loginPage() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel11 = new javax.swing.JLabel();
        jWelcome = new javax.swing.JPanel();
        panelLogo = new javax.swing.JPanel();
        logoLaki = new javax.swing.JLabel();
        copyright = new javax.swing.JLabel();
        planifyDesc = new javax.swing.JLabel();
        welcomeText = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        usernameField = new javax.swing.JTextField();
        passwordText = new javax.swing.JLabel();
        passwordField = new javax.swing.JTextField();
        loginButton = new javax.swing.JButton();
        questionLogin = new java.awt.Label();
        registerButton = new javax.swing.JButton();
        welcomeDesc = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jWelcome.setBackground(new java.awt.Color(250, 237, 205));
        jWelcome.setPreferredSize(new java.awt.Dimension(800, 450));

        panelLogo.setBackground(new java.awt.Color(212, 163, 115));
        panelLogo.setPreferredSize(new java.awt.Dimension(400, 281));

        copyright.setFont(new java.awt.Font("Baskerville Old Face", 0, 12)); // NOI18N
        copyright.setText("Copyright @Planify 2023 ");

        planifyDesc.setFont(new java.awt.Font("Baskerville Old Face", 3, 16)); // NOI18N
        planifyDesc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        planifyDesc.setText("your personal weekly planner");

        javax.swing.GroupLayout panelLogoLayout = new javax.swing.GroupLayout(panelLogo);
        panelLogo.setLayout(panelLogoLayout);
        panelLogoLayout.setHorizontalGroup(
            panelLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLogoLayout.createSequentialGroup()
                .addGroup(panelLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelLogoLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(logoLaki, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelLogoLayout.createSequentialGroup()
                        .addGap(140, 140, 140)
                        .addComponent(copyright))
                    .addGroup(panelLogoLayout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(planifyDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        panelLogoLayout.setVerticalGroup(
            panelLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLogoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoLaki, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(planifyDesc)
                .addGap(124, 124, 124)
                .addComponent(copyright)
                .addGap(22, 22, 22))
        );

        welcomeText.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        welcomeText.setText("Welcome Back!");

        username.setFont(new java.awt.Font("Baskerville Old Face", 0, 16)); // NOI18N
        username.setText("Username");

        usernameField.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        usernameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameFieldActionPerformed(evt);
            }
        });

        passwordText.setFont(new java.awt.Font("Baskerville Old Face", 0, 16)); // NOI18N
        passwordText.setText("Password");

        passwordField.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        loginButton.setBackground(new java.awt.Color(204, 213, 174));
        loginButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 14)); // NOI18N
        loginButton.setText("Login");
        loginButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        questionLogin.setFont(new java.awt.Font("Baskerville Old Face", 0, 14)); // NOI18N
        questionLogin.setText("Already have an account?");

        registerButton.setBackground(new java.awt.Color(212, 163, 115));
        registerButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 14)); // NOI18N
        registerButton.setText("Register");
        registerButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        registerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerButtonActionPerformed(evt);
            }
        });

        welcomeDesc.setFont(new java.awt.Font("Baskerville Old Face", 1, 16)); // NOI18N
        welcomeDesc.setText("Login into your account");

        javax.swing.GroupLayout jWelcomeLayout = new javax.swing.GroupLayout(jWelcome);
        jWelcome.setLayout(jWelcomeLayout);
        jWelcomeLayout.setHorizontalGroup(
            jWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jWelcomeLayout.createSequentialGroup()
                .addComponent(panelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addGroup(jWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jWelcomeLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(questionLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(registerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(username)
                        .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passwordText)
                        .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(welcomeText)
                        .addGroup(jWelcomeLayout.createSequentialGroup()
                            .addGap(58, 58, 58)
                            .addComponent(welcomeDesc))))
                .addGap(56, 56, 56))
        );
        jWelcomeLayout.setVerticalGroup(
            jWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelLogo, javax.swing.GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
            .addGroup(jWelcomeLayout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(welcomeText)
                .addGap(18, 18, 18)
                .addComponent(welcomeDesc)
                .addGap(18, 18, 18)
                .addComponent(username)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(registerButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(questionLogin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(129, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jWelcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        String username, Password, query, name = null, dbPass = null;
        String SUrl, SUser, Spassword;
        SUrl = "jdbc:MySQL://localhost:3306/weeklyplanner";
        SUser = "root";
        Spassword = "";
        int notFound = 0;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, Spassword);
            Statement st = con.createStatement();
            if("".equals(usernameField.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Username is Required.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }else if("".equals(passwordField.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Password is Required", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }else{
                username = usernameField.getText();
                Password = passwordField.getText();
                
                query = "SELECT * FROM pengguna WHERE username= '"+username+"'";
                ResultSet rs = st.executeQuery(query);
                while(rs.next()){
                    dbPass = rs.getString("passwordUser");
                    name = rs.getString("username");
                    notFound  = 1;
                }    
              
                
                if(notFound == 1 && Password.equals(dbPass)){
                    new Home(username).setVisible(true);
//                    homeFrame.pack();
//                    homeFrame.setLocationRelativeTo(null);
                     this.dispose();                 
                }else {
                 JOptionPane.showMessageDialog(new JFrame(), "Incorrect Email or Password", "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
                passwordField.setText("");
            }
        }catch(HeadlessException | ClassNotFoundException | SQLException e){
            System.out.println("Error!"+ e.getMessage());
            
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void registerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerButtonActionPerformed
        registerPage registerFrame = new registerPage(); 
        registerFrame.setVisible(true);
        registerFrame.pack();
        registerFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_registerButtonActionPerformed

    private void usernameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel copyright;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JPanel jWelcome;
    private javax.swing.JButton loginButton;
    private javax.swing.JLabel logoLaki;
    private javax.swing.JPanel panelLogo;
    private javax.swing.JTextField passwordField;
    private javax.swing.JLabel passwordText;
    private javax.swing.JLabel planifyDesc;
    private java.awt.Label questionLogin;
    private javax.swing.JButton registerButton;
    private javax.swing.JLabel username;
    private javax.swing.JTextField usernameField;
    private javax.swing.JLabel welcomeDesc;
    private javax.swing.JLabel welcomeText;
    // End of variables declaration//GEN-END:variables
}
