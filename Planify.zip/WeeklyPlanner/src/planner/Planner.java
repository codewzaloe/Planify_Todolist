package planner;

public class Planner {

    public static void main(String[] args) {
        loginPage LoginFrame = new loginPage(); 
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
    }
    
}
