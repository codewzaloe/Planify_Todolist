package weeklyplanner;

public class WeeklyPlanner {
    public static void main(String[] args) {
        
    }
    
}
