package weeklyplanner;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dbconnection {
    static final String DB_URL = "jdbc:mysql://localhost/oop";
    static final String USER = "root";
    static final String PASS = "";
    static final String QUERY = "SELECT * FROM user";
    
    public static void main(String[] args) {
        try(
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);){
            // create statement nya yang bisa banyak kali : stmt untuk execute, rs untuk hasilnya
            
            while(rs.next()){
                System.out.println("Id: " + rs.getString("id"));
                System.out.println("Nama: " + rs.getString("nama")); // parameternya itu nama kolomnya
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("No hp: " + rs.getString("NoHp"));
                System.out.println("===========================");
                System.out.println();
            }
            
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}